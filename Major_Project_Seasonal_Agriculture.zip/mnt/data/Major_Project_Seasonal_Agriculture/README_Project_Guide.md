# Major Project Submission Guide

Project: Seasonal Agriculture Performance Analysis

## Files included
1. Seasonal_Agriculture_Performance_Analysis.ipynb - complete beginner-friendly notebook
2. seasonal_agriculture_cleaned.csv - cleaned dataset
3. season_summary.csv - season-wise summary
4. crop_summary.csv - crop-wise summary
5. correlation_matrix.csv - correlation table
6. figures/ - 7 charts for the PPT

## Dataset
Rows: 4000
Columns: 28

## Missing values before cleaning
Rainfall_mm          48
Soil_Moisture_pct    40
Yield_Tonnes_Ha      32

## Main results from this dataset
Highest average yield season: Kharif (5.63)
Highest average profit season: Kharif (INR 178914.65)
Highest average water efficiency season: Kharif (5.89)
Highest average yield crop: Sugarcane (46.64)
Highest average profit crop: Sugarcane (INR 817187.99)

## PPT
Use the provided PPT template. Put the generated charts into the Results slides and paste the corresponding code snippets from the notebook into the code screenshot sections.

## Important
Run the notebook once in Google Colab or Jupyter before final submission so the code outputs and graphs are visible.
